MRTRUMAN/Project Outputs for MRTRUMAN contains the schematics PDFs and BOM for the project.

MRTRUMAN.PrjPcb should open with our schematics, schlibs, and pcblibs.